<?php global $newtheme;?>
<?php get_header();?>       
        <!-- breadcrumb -->
         <div class="breadcrumb-area" style="background: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)) repeat scroll 0% 0%, rgba(0, 0, 0, 0.25) url(<?php echo $newtheme['banner_image']['url'];?>) no-repeat;background-size:cover;background-position:center;">
            <div class="container">
                <div class="breadcrumb-content text-center">
                    <h2 data-aos="fade-up" data-aos-delay="200"><?php the_title();?></h2>
                    <ul data-aos="fade-up" data-aos-delay="400">
                        <li><a href="<?php bloginfo('url'); ?>">Home</a></li>
                        <li><i class="ti-angle-right"></i></li>
                        <li><?php the_title();?></li>
                    </ul>
                </div>
            </div>
        </div>
        <!-- end breadcrumb -->
        
        <?php				
			 if ( have_posts() ) : while (have_posts()) : the_post();
                						 		
    ?>	
   <div class="sec-pdgn extra-cls pages-pdgn">
       
          <div class="container <?php if(is_page('cart') ) { echo 'cart-only' ;} ?> <?php if(is_page('checkout') ) { echo 'checkout-cls' ;} ?> <?php if(is_page('my-account') ) { echo 'lost-cls' ;} ?>">  
       <?php if(is_page('my-account')) { ?>
            <div class="row">
                <div class="col-md-12 mx-auto">
                    <?php the_content();?>
                </div>
        </div>
    <?php } else { ?>
        <?php the_content();?>
    <?php } ?>
    </div> 
</div>
     <?php endwhile; endif; ?>   
        <div class="product-area ">
  <?php get_footer();?>       