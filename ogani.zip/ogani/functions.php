<?php 

$themename = 'Ogani';
    // This theme uses wp_nav_menu() in header location.  

  // for dynamic nav items
register_nav_menus( array(  
  'primary' => __( 'Header Menu', '$themename' ),
  // 'header' => __( 'Header Main Menu', '$themename' ), 

) );

// navwalker
require_once(get_template_directory().'/inc/class-wp-bootstrap-navwalker.php');

require_once(get_template_directory().'/inc/custom-widget.php');

// woocommerce
function mytheme_add_woocommerce_support() {
    add_theme_support( 'woocommerce' );
}

add_action( 'after_setup_theme', 'mytheme_add_woocommerce_support' );






    //Theme Title-tag support
add_theme_support( 'title-tag' );
add_theme_support( 'post-thumbnails' );

// add image sizes
add_image_size('breadcumb_image',1920,767,true);
add_image_size('menu-image',102,102,true);
add_image_size('blog-image',1420,1420,true);
add_image_size('blog-image-1',780,560,true);
// add_image_size('about-image',569,569,true);


// acf code
if( function_exists('acf_add_options_page') ) {

    acf_add_options_page(array(
        'page_title'    => 'Theme General Settings',
        'menu_title'    => 'Theme Settings',
        'menu_slug'     => 'theme-general-settings',
        'capability'    => 'edit_posts',
        'redirect'      => false
    ));
    
    acf_add_options_sub_page(array(
        'page_title'    => 'Theme Header Settings',
        'menu_title'    => 'Header',
        'parent_slug'   => 'theme-general-settings',
    ));
    
    acf_add_options_sub_page(array(
        'page_title'    => 'Theme Footer Settings',
        'menu_title'    => 'Footer',
        'parent_slug'   => 'theme-general-settings',
    ));
    

    acf_add_options_sub_page(array(
        'page_title'    => 'Theme 404 Page Settings',
        'menu_title'    => '404 Pages',
        'parent_slug'   => 'theme-general-settings',
    ));
}

//count cart item







